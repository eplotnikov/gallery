﻿<?php

    //обработка формы авторизации
    $login = $_POST['login'];
    $password = $_POST['password'];

    if (!empty($login) && !empty($password))
    {

		require_once '../models/model_authorization.php';
		$authorization = new Model_Authorization();
		$res = $authorization -> isset_User();
		print_r($res);
			
		foreach ($res as $k => $val)
		{
			if ($val == $login)
			{
				session_start();
				$_SESSION['login'] = $login;
				//header('Location: http://gallery.dev/');
				header('Location: http://plov.dp.ua/');
			} else {
				//header('Location: http://gallery.dev/');
				header('Location: http://plov.dp.ua/authorization');
			}
		}
		
    } else {
        echo "not found";
    }

?>










