﻿<?php

	session_start();
	unset($_SESSION['login']);
    //header('Location: http://gallery.dev/');
	header('Location: http://plov.dp.ua/');

?>



