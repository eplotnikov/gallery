﻿<?php

	include_once '../models/model_admin.php';

    //delete user
    if (isset($_POST['deleteUser']))
    {
        $deleteUser = $_POST['deleteUser'];
        include_once '../models/model_admin.php';
        $delUser = new Model_Admin();
        $delUser -> delVal("users", "name", $deleteUser);
    }

    //add new galleries wiht pic
    if (isset($_POST['nameGallery']))
    {
        if (empty($_FILES['photoGallery']['name']))
        {
            $avatar = "img/albums/img0001.jpg";
            $photoGallery = "img0001.jpg";
        } else {
            $path_directory = '../../img/albums/';
            $photoGallery = $_FILES['photoGallery']['name'];
        }
        if (preg_match('/[.](JPG)|(jpg)|(jpeg)|(JPEG)|(gif)|(GIF)|(png)|(PNG)$/', $_FILES['photoGallery']['name']))
        {
            $filename = $_FILES['photoGallery']['name'];
            $source = $_FILES['photoGallery']['tmp_name'];
            $target = $path_directory . $filename;
            move_uploaded_file($source, $target);
            //header('Location: http://gallery.dev/');
            header('Location: http://plov.dp.ua/');
        }
        $nameGallery = $_POST['nameGallery'];
        $commentGallery = $_POST['commentGallery'];
        $addGallery = new Model_Admin();
        $addGallery -> addInfo($nameGallery, $commentGallery, $photoGallery, "gallerys", "name, comment, photo");
    }


    if (isset($_POST['nameAddPhoto']))
    {
        //echo $namePhoto = $_POST['nameAddPhoto'];
        //print_r ($_FILES['fileAddPhoto']['name']);
        if (empty($_FILES['fileAddPhoto']['name']))
        {
            $avatar = "img/albums/img0001.jpg";
            $photoGallery = "img0001.jpg";

        } else {
            $path_directory = '../../img/photo/';
            $photoGallery = $_FILES['fileAddPhoto']['name'];

        }

        if (preg_match('/[.](JPG)|(jpg)|(jpeg)|(JPEG)|(gif)|(GIF)|(png)|(PNG)$/', $_FILES['fileAddPhoto']['name']))
        {
            $filename = $_FILES['fileAddPhoto']['name'];
            $source = $_FILES['fileAddPhoto']['tmp_name'];
            $target = $path_directory . $filename;
            move_uploaded_file($source, $target);
            //header('Location: http://gallery.dev/');
            header('Location: http://plov.dp.ua/');
        }
        /*$nameGallery = $_POST['nameGallery'];
        $commentGallery = $_POST['commentGallery'];
        $addGallery = new Model_Admin();
        $addGallery -> addInfo($nameGallery, $commentGallery, $photoGallery, "gallerys", "name, comment, photo");*/

        echo $namePhoto = $_POST['nameAddPhoto'];
        echo $commentPhoto = $_POST['CommentAddPhoto'];
        echo $galleryPhoto = $_POST['GalleryAddPhoto'];
        echo $filename;
        //exit();
        $addGallery = new Model_Admin();
        $addGallery -> addInfo($namePhoto, $commentPhoto, $galleryPhoto, "photos", "name, comment, name_galleries");

        //$addPhoto -> addPhotoInfo($namePhoto, $commentPhoto, $galleryPhoto, $filename, "photos", "name, comment, picture, show, name_galleries, name_user");
            //header('Location: http://gallery.dev/');
            header('Location: http://plov.dp.ua/');


    }
	
	//delete gallery
	if (isset($_POST['deleteGallery']))
    {
        $deleteGallery = $_POST['deleteGallery'];
        include_once '../models/model_admin.php';
        $delGallery = new Model_Admin();
        $delGallery -> delVal("gallerys", "name", $deleteGallery);
    }
	
	//deleteUserPhoto
	if (isset($_POST['deleteUserPhoto']))
    {	
		echo $_POST['deleteUserPhoto'];
        $deletePhoto = $_POST['deleteUserPhoto'];
        include_once '../models/model_admin.php';
        $delPhoto = new Model_Admin();
        $delPhoto -> delVal("photos", "picture", $deletePhoto);
		unlink ("../../img/photo/".$deletePhoto);
    }

	//deletePhotoAdmin
	if (isset($_POST['deletePhotoAdmin']))
    {	
		echo $_POST['deletePhotoAdmin'];
        $deletePhoto = $_POST['deletePhotoAdmin'];
        include_once '../models/model_admin.php';
        $delPhoto = new Model_Admin();
        $delPhoto -> delVal("photos", "picture", $deletePhoto);
		unlink ("../../img/photo/".$deletePhoto);
    }
	
	//update role
    if (isset($_POST['UserForRole']))
    {
        $user = $_POST['UserForRole'];
		$role = $_POST['RoleForUser'];
        include_once '../models/model_admin.php';
        $delUser = new Model_Admin();
        $delUser -> updateInfo("users", "role", $role, "login", $user);
    }
	
	//update gallery
    if (isset($_POST['editGalleryName']))
    {
        $galleryName = $_POST['editGalleryName'];
		$newGalleryName = $_POST['nameForEditGallery'];
		$newGalleryComment = $_POST['commentForEditGallery'];
        include_once '../models/model_admin.php';
        $delUser = new Model_Admin();
        $delUser -> updateInfo("gallerys", "name", $newGalleryName, "name", $galleryName);
		$delUser -> updateInfo("gallerys", "comment", $newGalleryComment, "name", $galleryName);
		if (!empty($_POST['photoForEditGallery']))
		{
			$path_directory = '../../img/albums/';
            $photoGallery = $_FILES['photoForEditGallery']['name'];
			if (preg_match('/[.](JPG)|(jpg)|(jpeg)|(JPEG)|(gif)|(GIF)|(png)|(PNG)$/', $_FILES['photoForEditGallery']['name']))
			{
				$filename = $_FILES['photoForEditGallery']['name'];
				$source = $_FILES['photoForEditGallery']['tmp_name'];
				$target = $path_directory . $filename;
				move_uploaded_file($source, $target);
				//header('Location: http://gallery.dev/');
				header('Location: http://plov.dp.ua/');
			}
			$delUser -> updateInfo("gallerys", "photo", $photoGallery, "name", $galleryName);
		}
    }
?>



