﻿
    <!-- страница "main", главная, слайдер карусель -->

    <div id="gal">

		<div id="gallery" style="margin:100px auto;">
			<img src="images/1.jpg" href="#" />
			<img src="images/2.jpg" href="#" />
			<img src="images/3.jpg" href="#" />
			<img src="images/4.jpg" href="#" />
			<img src="images/5.jpg" href="#" />
			<img src="images/6.jpg" href="#" />
			<img src="images/7.jpg" href="#" />
		</div>

    </div>
		
		
