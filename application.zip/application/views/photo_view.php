﻿
	<!-- "gallery", выводит ссылки-превьюшки всех альбомов -->
		
		<div id="container">
				
		Photo
		
		</div>
		
		
