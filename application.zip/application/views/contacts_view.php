﻿
    <!-- страница "contacts", контакты -->

        <div id="inform_block">
            <h1>Contacts</h1>
            <hr>
            <p class="homeText">
            <b><?php print_r($data[0]) ; print_r ($data[1]) ; ?></b><br/>
            address: <?php print_r($data[2]); ?><br/>
            phone: <?php print_r($data[3]); ?><br/>
            skype: <?php print_r($data[4]); ?><br/>
            e-mail: <?php print_r($data[5]); ?><br/>
            info: <?php print_r($data[6]); ?><br/>
            </p>
            <br/>
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d169368.64858452204!2d35.176918918870946!3d48.44913957992358!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sru!2sua!4v1409897232380" width="600" height="450" frameborder="0" style="border:0"></iframe>
        </div>
