﻿
    <!-- страница "authorization", выводит форму авторизации -->
	
		<div id="inform_block">

			<h1>Authorization</h1>
			<hr>
			<form name="authorization" method="POST" action="application/extra/authorizationForm.php">
			  
			  <p><input type="text" name="login"> Login</p>
			  <br>
			  <p><input type="password" name="password"> Password</p>
			  <br>
			  <p><input type="submit" value="go!"></p>
			  <br>
				
			</form>
			
		</div>