﻿
    <!-- страница "registration", страница отображения формы регистрации -->

        <div id="inform_block">

            <h1>Registration</h1>
            <hr>
            <form name="authorization" method="POST"  action="application/extra/registrationForm.php" >

              <p><input type="text" name="login"> Login</p>
              <br>
              <p><input type="text" name="name"> Name</p>
              <br>
              <p><input type="text" name="surname"> Surname</p>
              <br>
              <p><input type="password" name="password1"> Password</p>
              <br>
              <p><input type="password" name="password2"> Password confirmation</p>
              <br>
              <p><input type="email" name="email"> E-mail</p>
              <br>
              <p>Men - <input type="radio" name="sex" value="men"> Women - <input type="radio" name="sex" value="women"> Sex</p>
              <br>
              <p><input type="submit" value="go!"></p>

            </form>

        </div>