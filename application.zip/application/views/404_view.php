﻿
    <!-- страница "404" -->

		<div id="inform_block">

			<h1>404</h1>
			<hr>
			<p>This page not found!</p>
			
		</div>